// Supabase config (anon public key injected)
window.SHERIFF_SUPABASE = { url: 'https://xozhissdonzcsxqxdido.supabase.co', key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhvemhpc3Nkb256Y3N4cXhkaWRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjEwNTExMzUsImV4cCI6MjA3NjYyNzEzNX0.3VtgAYUaE91nRrrbfdTDJs1wXEEqwQBw9Tjw-jWslhs' };
